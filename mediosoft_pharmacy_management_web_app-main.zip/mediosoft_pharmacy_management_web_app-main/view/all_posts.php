<?php
$page_title = "All Posts - MedioSoft";
include_once('../view/component/dashboard_sidebar.php');
require_once('../controller/check_login_status.php');
if(!check_login_status()){
    header('location: login.php');
}
include_once('../model/usersModel.php');
include_once('../model/postsModel.php');
$posts = get_all_posts_data();
$get_current_user_info = get_current_user_info();

?>

<!-- including header -->
<?php include_once('../view/component/dashboard_header.php'); ?>

<div class="main-section">
                <div class="container">
                    <div class="row">
                        <div class="column-thirty-three">
                            <div class="dashboard-sidebar">
                                <?php echo get_sidebar();?>
                            </div>
                        </div>
                        <div class="column-sixty-six">
                            <div class="table-data">
                                <div class="form-title">
                                    <h3>All Posts</h3>
                                </div>

                                <div class="all-medicines">
                                    <table class="table" id="show_post" width="100%">


                                    </table>
                                </div>
                                <div id="status_messages"></div>
                            </div>
                        </div>
                    </div>
              
                </div>


    <script>
            showPosts();
            //fetching posts data using ajax
            function showPosts(){

                let action = 'get_data';
                let xhttp = new XMLHttpRequest();
                xhttp.open('GET', '../controller/postsController.php?action='+action, true);

                xhttp.send();
                xhttp.onreadystatechange = function(){
                    if(this.readyState == 4 && this.status == 200){
                        document.getElementById('show_post').innerHTML = this.responseText;
                    }
                }
            }

        //delete operation using ajax
        function deletePost(event){
            event.preventDefault();
            alert('Are you sure to delete this Post?');
            let post_id = event.target.getAttribute('data-post-id');
            post_id = parseInt(post_id);

            let action = 'delete_post';
            let xhttp = new XMLHttpRequest();
            xhttp.open('GET', '../controller/postsController.php?action='+action+'&post_id='+post_id, true);
            xhttp.send();
            xhttp.onreadystatechange = function(){

                if(this.readyState == 4 && this.status == 200){
                    document.getElementById('status_messages').innerHTML = this.responseText;
                    showPosts();
                }
            }

        }
    </script>
    
<!-- including footer -->
<?php include_once('../view/component/footer.php'); ?>